import React from 'react'

const Fish = () => {
  return (
    <div>Fish</div>
  )
}

export default Fish