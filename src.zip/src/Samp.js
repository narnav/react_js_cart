import React from 'react'

const Samp = () => {
  return (
    <div>Samp</div>
  )
}

export default Samp