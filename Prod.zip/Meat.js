import React from 'react'

const Meat = () => {
  return (
    <div>Meat</div>
  )
}

export default Meat