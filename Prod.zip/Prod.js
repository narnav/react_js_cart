import React, { useEffect, useState } from 'react'
import { useParams } from "react-router-dom";
import { getProductsByCategory, getCategoryName } from './myData';

const Prod = () => {
    let catid = useParams().catid;
    const [cart, setcart] = useState([])
    const [Total, setTotal] = useState(0)
  
    useEffect(() => {
        let temp = 0
        cart.forEach(item => temp += parseInt(item.price.replace('$', '').replace(",", "")) * item.amount)
        setTotal(temp)
    }, [cart])

    const buy = (pro, deltaAmount) => {
        let tempProduct = cart.filter(prod => prod.id == pro.id)[0]

        if (tempProduct) {//if exist (update amount)
            tempProduct.amount += deltaAmount
            if (tempProduct.amount == 0) { //amount == 0 , product should remove
                console.log("this item should b remove");
                setcart([...cart.filter(prod => prod.id != pro.id)])
            }
            else {
                setcart([...cart])//call the useEffect - to calc the Total,amount update
            }
        } else {//not exist -  add new item 2 the list
            pro.amount = 1
            setcart([pro, ...cart]); //add product 2 my cart , call to useEffect
        }
    }

    return (
        <div>
            <h1> Products : {getProductsByCategory(catid).length} from  {getCategoryName(catid)}</h1>

            {getProductsByCategory(catid).map(prod => <div key={prod.id}>
                {prod.name} ,{prod.price}
                <button onClick={() => buy(prod, 1)}>Buyyyyy</button>
            </div>)}

            <hr />
            Your cart
            {cart.map((pro, ind) =>
                <div key={ind}>
                    <button onClick={() => buy(pro, 1)}>+</button>
                    Desc:{pro.name} Price:{pro.price},Amount:{pro.amount}
                    <button onClick={() => buy(pro, -1)}>-</button>
                </div>)}
            ${Total}
        </div>
    )
}

export default Prod